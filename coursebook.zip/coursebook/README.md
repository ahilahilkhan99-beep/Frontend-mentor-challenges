# CourseBook

A course-catalog demo: React (Vite) frontend with a Three.js ambient
visual, backed by a real Node.js/Express API. Editorial, minimal design
with light/dark mode.

## Structure
```
coursebook/
  server/   → Express API (courses, categories, enroll)
  client/   → React + Vite frontend (Three.js scene, catalog UI)
```

## Run it

You need two terminals — the API and the frontend run separately.

**1) Start the API**
```bash
cd server
npm install
npm run dev
```
Runs at http://localhost:4000. Test it directly: http://localhost:4000/api/courses

**2) Start the frontend**
```bash
cd client
npm install
npm run dev
```
Runs at http://localhost:5173 — open this in your browser.
Vite proxies `/api/*` requests to the Express server automatically
(configured in `vite.config.js`), so just open the frontend URL.

## What's real vs. demo
- Course data, search, and category filtering are served from the
  Express API (`GET /api/courses?search=&category=`).
- Enrolling calls `POST /api/enroll` and is stored in memory on the
  server (resets when you restart the server) — check it via
  `GET /api/enrollments`.
- Favourites are stored in the browser's `localStorage` since there's
  no login system — add one later if you want favourites to sync
  across devices.
- If the API isn't running, the frontend automatically falls back to
  local sample data so the UI still works — you'll see a small warning
  banner when that happens.

## Notes
- Three.js scene lives in `client/src/components/Scene.jsx` — a wireframe
  icosahedron with scattered nodes, rotating slowly, with a subtle
  mouse-parallax tilt. It respects `prefers-reduced-motion`.
- Design tokens (colors, fonts) are in `client/src/index.css` — edit
  `--accent` there to change the whole theme's accent color.
- To go to production: `npm run build` in `/client`, then serve the
  `dist/` folder from Express (or any static host) and point it at your
  deployed API URL.
