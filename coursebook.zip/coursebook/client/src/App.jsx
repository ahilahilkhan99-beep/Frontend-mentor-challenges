import { useEffect, useState, useCallback, useRef } from "react";
import Header from "./components/Header.jsx";
import Hero from "./components/Hero.jsx";
import SearchFilter from "./components/SearchFilter.jsx";
import CourseList from "./components/CourseList.jsx";
import Modal from "./components/Modal.jsx";
import Toast from "./components/Toast.jsx";
import { fallbackCategories, filterFallback } from "./data/fallbackCourses.js";
import "./App.css";

export default function App() {
  const [theme, setTheme] = useState("light");
  const [courses, setCourses] = useState([]);
  const [categories, setCategories] = useState(fallbackCategories);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [favourites, setFavourites] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("cb_favourites")) || [];
    } catch {
      return [];
    }
  });
  const [showingFavOnly, setShowingFavOnly] = useState(false);
  const [modalCourse, setModalCourse] = useState(null);
  const [toastMsg, setToastMsg] = useState("");
  const [apiError, setApiError] = useState(false);
  const toastTimer = useRef(null);

  // theme -> <html data-theme="">
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  // fetch category list once
  useEffect(() => {
    fetch("/api/categories")
      .then((r) => {
        if (!r.ok) throw new Error("bad response");
        return r.json();
      })
      .then(setCategories)
      .catch(() => setApiError(true));
  }, []);

  // fetch courses whenever search/category changes
  useEffect(() => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (category && category !== "All") params.set("category", category);

    fetch(`/api/courses?${params.toString()}`)
      .then((r) => {
        if (!r.ok) throw new Error("bad response");
        return r.json();
      })
      .then((data) => {
        setCourses(data);
        setApiError(false);
      })
      .catch(() => {
        setApiError(true);
        setCourses(filterFallback(search, category));
      });
  }, [search, category]);

  // persist favourites
  useEffect(() => {
    localStorage.setItem("cb_favourites", JSON.stringify(favourites));
  }, [favourites]);

  function showToast(msg) {
    setToastMsg(msg);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToastMsg(""), 2400);
  }

  const toggleFav = useCallback((course) => {
    setFavourites((prev) => {
      const exists = prev.some((f) => f.id === course.id);
      if (exists) {
        showToast(`Removed "${course.title}" from favourites`);
        return prev.filter((f) => f.id !== course.id);
      }
      showToast(`Added "${course.title}" to favourites`);
      return [...prev, course];
    });
  }, []);

  async function confirmEnroll(course) {
    try {
      const res = await fetch("/api/enroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ courseId: course.id })
      });
      const data = await res.json();
      showToast(data.message || `Enrolled in "${course.title}"`);
    } catch {
      showToast(`Enrolled in "${course.title}" (offline demo — server not running)`);
    } finally {
      setModalCourse(null);
    }
  }

  const visibleCourses = showingFavOnly ? favourites : courses;

  return (
    <>
      <Header
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === "light" ? "dark" : "light"))}
        showingFavOnly={showingFavOnly}
        onToggleFav={() => setShowingFavOnly((v) => !v)}
      />

      <Hero theme={theme} courseCount={courses.length || 12} />

      {apiError && (
        <p className="api-warning mono">
          Could not reach the API — start it with <code>npm run dev</code> inside{" "}
          <code>/server</code>. Showing local data for now.
        </p>
      )}

      <SearchFilter
        categories={categories}
        currentCategory={category}
        onCategoryChange={setCategory}
        search={search}
        onSearchChange={setSearch}
      />

      <CourseList
        courses={visibleCourses}
        favourites={favourites}
        onToggleFav={toggleFav}
        onEnroll={setModalCourse}
      />

      <Modal
        course={modalCourse}
        onClose={() => setModalCourse(null)}
        onConfirm={confirmEnroll}
      />

      <Toast message={toastMsg} />

      <footer className="site-footer mono">© CourseBook — a demo catalog.</footer>
    </>
  );
}
