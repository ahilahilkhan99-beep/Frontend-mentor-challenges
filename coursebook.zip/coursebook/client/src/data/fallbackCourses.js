export const fallbackCourses = [
  { id: 1,  title: "HTML Foundations",            category: "HTML",        level: "Beginner",     duration: "4h 20m",  price: 19, students: 12400, description: "Build a rock-solid understanding of semantic HTML, forms, accessibility and page structure from scratch." },
  { id: 2,  title: "CSS Mastery: Flexbox & Grid",  category: "CSS",         level: "Beginner",     duration: "5h 10m",  price: 24, students: 9800,  description: "Go from box-model basics to full responsive layouts using Flexbox, Grid and modern CSS features." },
  { id: 3,  title: "JavaScript Deep Dive",         category: "JavaScript", level: "Intermediate", duration: "9h 45m",  price: 39, students: 21200, description: "Master closures, async/await, prototypes and the DOM by building real interactive projects." },
  { id: 4,  title: "React from Zero to Hero",      category: "React",      level: "Intermediate", duration: "11h 5m",  price: 49, students: 17600, description: "Learn components, hooks, state management and routing while building a full production app." },
  { id: 5,  title: "Node.js API Development",      category: "Node.js",    level: "Intermediate", duration: "7h 30m",  price: 44, students: 8300,  description: "Design and ship REST APIs with Express, middleware, authentication and error handling." },
  { id: 6,  title: "Git & GitHub Essentials",      category: "Tools",      level: "Beginner",     duration: "3h 15m",  price: 15, students: 14100, description: "Branch, merge, rebase and collaborate confidently using Git and GitHub workflows." },
  { id: 7,  title: "SQL & Database Design",        category: "Database",   level: "Intermediate", duration: "8h 0m",   price: 34, students: 6900,  description: "Design normalized schemas and write efficient SQL queries for real-world applications." },
  { id: 8,  title: "Building REST APIs",           category: "Backend",    level: "Advanced",     duration: "10h 20m", price: 54, students: 5400,  description: "Architect scalable backend services with authentication, caching and rate limiting." },
  { id: 9,  title: "Firebase for Web Apps",        category: "Firebase",   level: "Intermediate", duration: "6h 0m",   price: 29, students: 4700,  description: "Add auth, a realtime database and hosting to your web app in a single afternoon." },
  { id: 10, title: "MERN Full Stack Bootcamp",     category: "Full Stack", level: "Advanced",     duration: "22h 0m",  price: 89, students: 11000, description: "Build, deploy and ship a complete MongoDB, Express, React and Node application." },
  { id: 11, title: "Web Performance Optimization", category: "Performance",level: "Advanced",     duration: "5h 40m",  price: 42, students: 3200,  description: "Cut load times with lazy loading, caching strategies, bundling and Core Web Vitals tuning." },
  { id: 12, title: "Land Your First Dev Job",      category: "Career",     level: "Beginner",     duration: "4h 0m",   price: 25, students: 9900,  description: "Build a portfolio, ace technical interviews and write a resume recruiters actually read." }
];

export const fallbackCategories = [
  "All", "HTML", "CSS", "JavaScript", "React", "Node.js", "Tools",
  "Database", "Backend", "Firebase", "Full Stack", "Performance", "Career"
];

export function filterFallback(search, category) {
  let data = fallbackCourses;
  if (category && category !== "All") {
    data = data.filter((c) => c.category === category);
  }
  if (search && search.trim()) {
    const q = search.toLowerCase();
    data = data.filter(
      (c) => c.title.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)
    );
  }
  return data;
}
