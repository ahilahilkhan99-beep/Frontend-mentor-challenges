export default function Toast({ message }) {
  return (
    <div className={`toast mono ${message ? "show" : ""}`}>
      {message}
    </div>
  );
}
