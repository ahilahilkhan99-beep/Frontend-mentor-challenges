import { useState } from "react";

export default function CourseRow({ course, index, isFav, onToggleFav, onEnroll }) {
  const [open, setOpen] = useState(false);

  return (
    <div className={`course-row ${open ? "open" : ""}`}>
      <div className="row-main" onClick={() => setOpen(!open)}>
        <span className="row-index mono">{String(index + 1).padStart(2, "0")}</span>

        <div className="row-title-block">
          <h3 className="row-title display">{course.title}</h3>
          <span className="row-meta mono">{course.category} · {course.level}</span>
        </div>

        <span className="row-duration mono">{course.duration}</span>
        <span className="row-price mono">${course.price}</span>

        <button
          className={`fav-toggle ${isFav ? "active" : ""}`}
          onClick={(e) => { e.stopPropagation(); onToggleFav(course); }}
          aria-label={isFav ? "Remove from favourites" : "Add to favourites"}
        >
          {isFav ? "★" : "☆"}
        </button>
      </div>

      <div className="row-detail" style={{ gridTemplateRows: open ? "1fr" : "0fr" }}>
        <div className="row-detail-inner">
          <p className="row-description">{course.description}</p>
          <span className="mono students-count">
            {Number(course.students).toLocaleString()} students enrolled
          </span>
          <button className="enroll-btn" onClick={() => onEnroll(course)}>
            Enroll — ${course.price}
          </button>
        </div>
      </div>
    </div>
  );
}
