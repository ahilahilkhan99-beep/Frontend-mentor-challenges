import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function Scene({ theme }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const width = mount.clientWidth;
    const height = mount.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.z = 6;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    mount.appendChild(renderer.domElement);

    const accentColor = theme === "dark" ? 0x9498ff : 0x5b5fef;

    const icosahedron = new THREE.IcosahedronGeometry(2.1, 2);
    const wireframe = new THREE.WireframeGeometry(icosahedron);
    const line = new THREE.LineSegments(
      wireframe,
      new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.5 })
    );
    scene.add(line);

    // scattered nodes across the same sphere, for a "network of knowledge" feel
    const nodeCount = 70;
    const nodePositions = new Float32Array(nodeCount * 3);
    for (let i = 0; i < nodeCount; i++) {
      const v = new THREE.Vector3().setFromSphericalCoords(
        2.15 + Math.random() * 0.25,
        Math.acos(2 * Math.random() - 1),
        Math.random() * Math.PI * 2
      );
      nodePositions[i * 3] = v.x;
      nodePositions[i * 3 + 1] = v.y;
      nodePositions[i * 3 + 2] = v.z;
    }
    const nodeGeo = new THREE.BufferGeometry();
    nodeGeo.setAttribute("position", new THREE.BufferAttribute(nodePositions, 3));
    const nodeMat = new THREE.PointsMaterial({ color: accentColor, size: 0.055 });
    const points = new THREE.Points(nodeGeo, nodeMat);
    scene.add(points);

    let mouseX = 0;
    let mouseY = 0;
    function onMouseMove(e) {
      const rect = mount.getBoundingClientRect();
      mouseX = (e.clientX - rect.left) / rect.width - 0.5;
      mouseY = (e.clientY - rect.top) / rect.height - 0.5;
    }
    mount.addEventListener("mousemove", onMouseMove);

    let frameId;
    function animate() {
      frameId = requestAnimationFrame(animate);
      line.rotation.y += 0.0016;
      line.rotation.x += 0.0006;
      points.rotation.y += 0.0016;
      points.rotation.x += 0.0006;
      camera.position.x += (mouseX * 1.1 - camera.position.x) * 0.04;
      camera.position.y += (-mouseY * 1.1 - camera.position.y) * 0.04;
      camera.lookAt(scene.position);
      renderer.render(scene, camera);
    }

    if (reduceMotion) {
      renderer.render(scene, camera);
    } else {
      animate();
    }

    function onResize() {
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    }
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", onResize);
      mount.removeEventListener("mousemove", onMouseMove);
      renderer.dispose();
      icosahedron.dispose();
      wireframe.dispose();
      nodeGeo.dispose();
      if (renderer.domElement.parentNode === mount) {
        mount.removeChild(renderer.domElement);
      }
    };
  }, [theme]);

  return <div ref={mountRef} className="scene-mount" aria-hidden="true" />;
}
