export default function Header({ theme, onToggleTheme, showingFavOnly, onToggleFav }) {
  return (
    <header className="site-header">
      <div className="logo display">CourseBook</div>
      <nav>
        <button
          className={`nav-link ${showingFavOnly ? "active" : ""}`}
          onClick={onToggleFav}
        >
          {showingFavOnly ? "All courses" : "Favourites"}
        </button>
        <a href="#catalog" className="nav-link">Catalog</a>
        <button className="theme-toggle mono" onClick={onToggleTheme} aria-label="Toggle color theme">
          {theme === "dark" ? "Light mode" : "Dark mode"}
        </button>
      </nav>
    </header>
  );
}
