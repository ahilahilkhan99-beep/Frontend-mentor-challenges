export default function SearchFilter({
  categories,
  currentCategory,
  onCategoryChange,
  search,
  onSearchChange
}) {
  return (
    <div className="search-filter">
      <input
        type="search"
        className="search-input mono"
        placeholder="Search the catalog…"
        value={search}
        onChange={(e) => onSearchChange(e.target.value)}
      />
      <div className="category-tabs">
        {categories.map((cat) => (
          <button
            key={cat}
            className={`tab mono ${currentCategory === cat ? "active" : ""}`}
            onClick={() => onCategoryChange(cat)}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>
  );
}
