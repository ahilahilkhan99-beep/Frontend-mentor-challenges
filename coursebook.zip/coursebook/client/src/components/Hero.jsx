import Scene from "./Scene.jsx";

export default function Hero({ theme, courseCount }) {
  return (
    <section className="hero">
      <div className="hero-copy">
        <p className="eyebrow mono">No. 001 — a working index</p>
        <h1 className="display hero-title">
          Courses for people who'd rather build than scroll.
        </h1>
        <p className="hero-sub">
          {courseCount} courses on HTML, CSS, JavaScript, React and Node —
          indexed, searchable, and served from a real API underneath.
        </p>
      </div>
      <div className="hero-visual">
        <Scene theme={theme} />
      </div>
    </section>
  );
}
