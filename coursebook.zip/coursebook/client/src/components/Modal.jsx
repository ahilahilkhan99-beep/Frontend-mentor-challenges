export default function Modal({ course, onClose, onConfirm }) {
  if (!course) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">&times;</button>
        <h3 className="display">{course.title}</h3>
        <p className="modal-desc">{course.description}</p>
        <p className="mono modal-price">${course.price}</p>
        <div className="modal-actions">
          <button className="enroll-btn" onClick={() => onConfirm(course)}>
            Confirm enrollment
          </button>
          <button className="cancel-btn" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
