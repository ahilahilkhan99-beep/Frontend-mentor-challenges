import CourseRow from "./CourseRow.jsx";

export default function CourseList({ courses, favourites, onToggleFav, onEnroll }) {
  if (!courses.length) {
    return (
      <p className="empty-state mono" id="catalog">
        No courses match. Try a different search or category.
      </p>
    );
  }

  return (
    <div className="course-list" id="catalog">
      <div className="list-head mono">
        <span></span>
        <span>Course</span>
        <span>Duration</span>
        <span>Price</span>
        <span></span>
      </div>
      <hr className="hairline" />
      {courses.map((course, i) => (
        <CourseRow
          key={course.id}
          course={course}
          index={i}
          isFav={favourites.some((f) => f.id === course.id)}
          onToggleFav={onToggleFav}
          onEnroll={onEnroll}
        />
      ))}
    </div>
  );
}
