import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// ---------------------------------------------------------------------
// In-memory data. Swap this for a real database later without changing
// the routes below — they only depend on this array's shape.
// ---------------------------------------------------------------------
const courses = [
  { id: 1,  title: "HTML Foundations",              category: "HTML",        level: "Beginner",     duration: "4h 20m",  price: 19, students: 12400, description: "Build a rock-solid understanding of semantic HTML, forms, accessibility and page structure from scratch." },
  { id: 2,  title: "CSS Mastery: Flexbox & Grid",    category: "CSS",         level: "Beginner",     duration: "5h 10m",  price: 24, students: 9800,  description: "Go from box-model basics to full responsive layouts using Flexbox, Grid and modern CSS features." },
  { id: 3,  title: "JavaScript Deep Dive",           category: "JavaScript", level: "Intermediate", duration: "9h 45m",  price: 39, students: 21200, description: "Master closures, async/await, prototypes and the DOM by building real interactive projects." },
  { id: 4,  title: "React from Zero to Hero",        category: "React",      level: "Intermediate", duration: "11h 5m",  price: 49, students: 17600, description: "Learn components, hooks, state management and routing while building a full production app." },
  { id: 5,  title: "Node.js API Development",        category: "Node.js",    level: "Intermediate", duration: "7h 30m",  price: 44, students: 8300,  description: "Design and ship REST APIs with Express, middleware, authentication and error handling." },
  { id: 6,  title: "Git & GitHub Essentials",        category: "Tools",      level: "Beginner",     duration: "3h 15m",  price: 15, students: 14100, description: "Branch, merge, rebase and collaborate confidently using Git and GitHub workflows." },
  { id: 7,  title: "SQL & Database Design",          category: "Database",   level: "Intermediate", duration: "8h 0m",   price: 34, students: 6900,  description: "Design normalized schemas and write efficient SQL queries for real-world applications." },
  { id: 8,  title: "Building REST APIs",             category: "Backend",    level: "Advanced",     duration: "10h 20m", price: 54, students: 5400,  description: "Architect scalable backend services with authentication, caching and rate limiting." },
  { id: 9,  title: "Firebase for Web Apps",          category: "Firebase",   level: "Intermediate", duration: "6h 0m",   price: 29, students: 4700,  description: "Add auth, a realtime database and hosting to your web app in a single afternoon." },
  { id: 10, title: "MERN Full Stack Bootcamp",       category: "Full Stack", level: "Advanced",     duration: "22h 0m",  price: 89, students: 11000, description: "Build, deploy and ship a complete MongoDB, Express, React and Node application." },
  { id: 11, title: "Web Performance Optimization",   category: "Performance",level: "Advanced",     duration: "5h 40m",  price: 42, students: 3200,  description: "Cut load times with lazy loading, caching strategies, bundling and Core Web Vitals tuning." },
  { id: 12, title: "Land Your First Dev Job",        category: "Career",     level: "Beginner",     duration: "4h 0m",   price: 25, students: 9900,  description: "Build a portfolio, ace technical interviews and write a resume recruiters actually read." }
];

// enrollments live in memory for this demo; restart clears them
const enrollments = [];

// GET /api/courses?search=&category=
app.get("/api/courses", (req, res) => {
  const { search = "", category = "" } = req.query;
  let result = courses;

  if (category && category !== "All") {
    result = result.filter(c => c.category === category);
  }
  if (search.trim()) {
    const q = search.toLowerCase();
    result = result.filter(
      c => c.title.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)
    );
  }
  res.json(result);
});

// GET /api/categories
app.get("/api/categories", (req, res) => {
  const categories = ["All", ...new Set(courses.map(c => c.category))];
  res.json(categories);
});

// GET /api/courses/:id
app.get("/api/courses/:id", (req, res) => {
  const course = courses.find(c => c.id === Number(req.params.id));
  if (!course) return res.status(404).json({ error: "Course not found" });
  res.json(course);
});

// POST /api/enroll  { courseId }
app.post("/api/enroll", (req, res) => {
  const { courseId } = req.body;
  const course = courses.find(c => c.id === Number(courseId));
  if (!course) return res.status(404).json({ error: "Course not found" });

  const enrollment = {
    id: enrollments.length + 1,
    courseId: course.id,
    courseTitle: course.title,
    enrolledAt: new Date().toISOString()
  };
  enrollments.push(enrollment);
  res.status(201).json({ message: `Enrolled in ${course.title}`, enrollment });
});

// GET /api/enrollments  (demo/debug endpoint)
app.get("/api/enrollments", (req, res) => {
  res.json(enrollments);
});

app.listen(PORT, () => {
  console.log(`CourseBook API running at http://localhost:${PORT}`);
});
